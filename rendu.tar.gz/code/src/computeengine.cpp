#include "computeengine.h"

int ComputeEngineA::nextId = 0;
int ComputeEngineB::nextId = 0;
int ComputeEngineC::nextId = 0;
